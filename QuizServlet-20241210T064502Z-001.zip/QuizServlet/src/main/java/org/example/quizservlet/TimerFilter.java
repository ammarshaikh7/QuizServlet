package org.example.quizservlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;public class TimerFilter implements Filter {
    private static final long TIME_LIMIT_MILLIS = 5 * 60 * 1000; // 5 minutes

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Initialization logic if needed
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        HttpSession session = httpRequest.getSession(false);
        String requestURI = httpRequest.getRequestURI();

        // Exclude timeout and other static files from filtering
        if (requestURI.endsWith("timeout.html")) {
            chain.doFilter(request, response);
            return;
        }

        if (session == null || session.getAttribute("startTime") == null) {
            httpResponse.sendRedirect("index.html");
            return;
        }

        long startTime = (long) session.getAttribute("startTime");
        long elapsedTime = System.currentTimeMillis() - startTime;

        if (elapsedTime > TIME_LIMIT_MILLIS) {
            session.invalidate();
            httpResponse.sendRedirect(httpRequest.getContextPath() + "/timeout.html"); // Use correct path

            return;
        }

        chain.doFilter(request, response);
    }
}
