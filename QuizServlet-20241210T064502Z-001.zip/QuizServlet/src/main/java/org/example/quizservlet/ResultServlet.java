package org.example.quizservlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ResultServlet extends HttpServlet {

    // Using a HashMap to store the correct answers with question numbers as keys
    private final Map<Integer, String> correctAnswers = new HashMap<>();

    @Override
    public void init() throws ServletException {
        // Initializing correct answers in the Map
        correctAnswers.put(1, "Paris");
        correctAnswers.put(2, "Earth");
        correctAnswers.put(3, "7");
        correctAnswers.put(4, "Blue");
        correctAnswers.put(5, "Java");
        correctAnswers.put(6, "Asia");
        correctAnswers.put(7, "7");
        correctAnswers.put(8, "H2O");
        correctAnswers.put(9, "USA");
        correctAnswers.put(10, "Sun");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve the session
        HttpSession session = request.getSession(false); // false: do not create a new session if one doesn't exist
        if (session == null) {
            response.sendRedirect("index.html"); // Redirect to login page if session is invalid
            return;
        }

        // Start building the result page
        response.setContentType("text/html");
        response.getWriter().println("<h1>Quiz Results</h1>");

        // Initialize the score counter
        int score = 0;

        // Iterate over the questions and compare user answers with correct answers
        for (int i = 1; i <= 10; i++) {
            // Get the user's answer from the session (using HashMap keys for questions)
            String userAnswer = (String) session.getAttribute("answer" + i);
            String correctAnswer = correctAnswers.get(i); // Get the correct answer from the map

            // Log the answers for debugging
            System.out.println("Question " + i + ":");
            System.out.println("User's Answer: " + (userAnswer != null ? userAnswer : "Not answered"));
            System.out.println("Correct Answer: " + correctAnswer);

            response.getWriter().println("<p>Question " + i + ": </p>");
            response.getWriter().println("<p>Your Answer: " + (userAnswer != null ? userAnswer : "Not answered") + "</p>");
            response.getWriter().println("<p>Correct Answer: " + correctAnswer + "</p>");

            // Check if the user's answer is correct
            if (userAnswer != null && userAnswer.equalsIgnoreCase(correctAnswer)) {
                score++; // Increment score for correct answers
                System.out.println("Correct answer for question " + i);
            } else {
                System.out.println("Incorrect answer for question " + i);
            }

            response.getWriter().println("<hr>");
        }

        // Display the user's score
        response.getWriter().println("<h2>Your Final Score: " + score + "/10</h2>");

        // Optionally invalidate session after displaying results (to end the session)
        session.invalidate();
        System.out.println("Session invalidated after displaying results.");
    }
}
