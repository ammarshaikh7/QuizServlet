package org.example.quizservlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;

public class LoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        response.setContentType("text/html");

        // Validate input
        if (email == null || password == null || email.isEmpty() || password.isEmpty()) {
            response.getWriter().println("<h1>Email and password are required!</h1>");
            response.getWriter().println("<a href='index.html'>Try Again</a>");
            return;
        }

        // Fetch user from the database
        RegistrationServlet.User user = RegistrationServlet.userDatabase.get(email);

        if (user != null && user.getPassword().equals(password)) {
            // Start session and store user data
            HttpSession session = request.getSession();
            session.setAttribute("user", user); // Store entire user object
            session.setAttribute("startTime", System.currentTimeMillis()); // Track session start time

            System.out.println("Login successful for: " + email);
            response.sendRedirect("Exam/question1.html"); // Redirect to first question
        } else {
            System.out.println("Invalid login attempt for: " + email);
            response.getWriter().println("<h1>Invalid email or password</h1>");
            response.getWriter().println("<a href='index.html'>Try Again</a>");
        }
    }
}
