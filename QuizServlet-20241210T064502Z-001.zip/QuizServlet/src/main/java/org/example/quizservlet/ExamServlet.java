package org.example.quizservlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ExamServlet extends HttpServlet {

    // Using a HashMap to store the correct answers with question numbers as keys
    private final Map<Integer, String> correctAnswers = new HashMap<>();

    @Override
    public void init() throws ServletException {
        // Initializing correct answers in the Map
        correctAnswers.put(1, "Paris");
        correctAnswers.put(2, "Earth");
        correctAnswers.put(3, "7");
        correctAnswers.put(4, "Blue");
        correctAnswers.put(5, "Java");
        correctAnswers.put(6, "Asia");
        correctAnswers.put(7, "7");
        correctAnswers.put(8, "H2O");
        correctAnswers.put(9, "USA");
        correctAnswers.put(10, "Sun");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get or create session
        HttpSession session = request.getSession(true);

        // Set the start time if it's the first question
        if (session.getAttribute("startTime") == null) {
            session.setAttribute("startTime", System.currentTimeMillis());
        }

        // Get the current question number
        Integer currentQuestion = (Integer) session.getAttribute("currentQuestion");
        if (currentQuestion == null) {
            currentQuestion = 1; // Starting with question 1
        }

        // Get the answer from the form
        String answer = request.getParameter("answer");
        if (answer != null) {
            // Store the user's answer in the session (using HashMap keys for questions)
            session.setAttribute("answer" + currentQuestion, answer);
            System.out.println("User's answer for question " + currentQuestion + ": " + answer);
        }

        // Proceed to the next question or finish if all questions are answered
        currentQuestion++;
        session.setAttribute("currentQuestion", currentQuestion);

        if (currentQuestion <= 10) {
            // Redirect to the next question
            System.out.println("Redirecting to question " + currentQuestion);
            response.sendRedirect("Exam/question" + currentQuestion + ".html");
        } else {
            // All questions are answered, redirect to ResultServlet
            System.out.println("All questions answered. Redirecting to ResultServlet.");
            response.sendRedirect("ResultServlet");
        }
    }
}
