package org.example.quizservlet;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.HashMap;

public class RegistrationServlet extends HttpServlet {
    public static final HashMap<String, User> userDatabase = new HashMap<>();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String college = request.getParameter("college");
        String education = request.getParameter("education");
        String mobile = request.getParameter("mobile");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        response.setContentType("text/html");

        // Validate input fields
        if (name == null || name.isEmpty() ||
                college == null || college.isEmpty() ||
                education == null || education.isEmpty() ||
                mobile == null || mobile.isEmpty() ||
                email == null || email.isEmpty() ||
                password == null || password.isEmpty()) {
            response.getWriter().println("<h1>All fields are required!</h1>");
            response.getWriter().println("<a href='registration.html'>Try Again</a>");
            return;
        }

        // Validate mobile number
        if (!mobile.matches("\\d{10}")) {
            response.getWriter().println("<h1>Invalid mobile number!</h1>");
            response.getWriter().println("<a href='registration.html'>Try Again</a>");
            return;
        }

        // Validate email
        if (!email.matches("^[\\w._%+-]+@[\\w.-]+\\.[a-zA-Z]{2,6}$")) {
            response.getWriter().println("<h1>Invalid email format!</h1>");
            response.getWriter().println("<a href='registration.html'>Try Again</a>");
            return;
        }

        // Check for duplicate email
        if (userDatabase.containsKey(email)) {
            response.getWriter().println("<h1>Email is already registered!</h1>");
            response.getWriter().println("<a href='registration.html'>Try Again</a>");
            return;
        }

        // Store the user in the database
        User newUser = new User(name, college, education, mobile, password);
        userDatabase.put(email, newUser);

        System.out.println("New user registered: " + email);

        // Redirect to login page
        response.getWriter().println("<h1>Registration Successful!</h1>");
        response.getWriter().println("<a href='index.html'>Go to Login</a>");
    }
    class User {
        private String name;
        private String college;
        private String education;
        private String mobile;
        private String password;

        public User(String name, String college, String education, String mobile, String password) {
            this.name = name;
            this.college = college;
            this.education = education;
            this.mobile = mobile;
            this.password = password;
        }

        public String getName() {
            return name;
        }

        public String getCollege() {
            return college;
        }

        public String getEducation() {
            return education;
        }

        public String getMobile() {
            return mobile;
        }

        public String getPassword() {
            return password;
        }
    }

}
